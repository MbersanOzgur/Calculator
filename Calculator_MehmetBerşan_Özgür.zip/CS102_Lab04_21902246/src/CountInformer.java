public interface CountInformer {

    public void countUpdated(Operation operation);
}
