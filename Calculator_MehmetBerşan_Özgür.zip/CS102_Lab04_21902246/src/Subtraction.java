public class Subtraction extends Operation{
    @Override
    public double calculateResult(int a, int b) {
        setBinaryOrUnary(true);
        return a - b;
    }
}
