import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorButton extends JButton implements ActionListener {

    Operation operation;
    JTextField number1;
    JTextField number2;
    JLabel result;
    JLabel operationDone;
    CountInformer countInformer;
    String operationName;

    public CalculatorButton(Operation operation, JTextField number1, JTextField number2, JLabel result, String operationName, JLabel operationDone, CountInformer countInformer){
        this.operation = operation;
        this.countInformer = countInformer;
        this.operationName = operationName;
        this.setText(operationName);
        this.number1 = number1;
        this.number2 = number2;
        this.result = result;
        this.operationDone = operationDone;
        this.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String a,b;
        a = number1.getText();
        b = number2.getText();
        if(a.equalsIgnoreCase("Number1") || b.equalsIgnoreCase("Number2")){
            result.setText("Result can not be calculated.");
        }
        else {
            int num1 = Integer.parseInt(a);
            int num2 = Integer.parseInt(b);
            result.setText("Result: " + operation.calculateResult(num1, num2));
            countInformer.countUpdated(operation);
            operationDone.setText(operationName + ": " + operation.getDone());
        }
    }
}
