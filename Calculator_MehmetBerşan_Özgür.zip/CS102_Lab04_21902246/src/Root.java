public class Root extends Operation{

    @Override
    public double calculateResult(int a, int b) {
        setBinaryOrUnary(false);
        return Math.sqrt(a);
    }
}
