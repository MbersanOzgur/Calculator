import javax.swing.*;
import java.awt.*;

public class CalculatorPanel extends JPanel implements CountInformer{

    Operation[] operations;
    CalculatorButton additionButton;
    CalculatorButton subtractionButton;
    CalculatorButton multiplicationButton;
    CalculatorButton divisionButton;
    UnaryCalculationButton rootButton;
    UnaryCalculationButton squareButton;
    UnaryCalculationButton cubeButton;
    UnaryCalculationButton factorialButton;
    JTextField number1;
    JTextField number2;
    JLabel result;
    JLabel addition;
    JLabel subtraction;
    JLabel multiplication;
    JLabel division;
    JLabel root;
    JLabel square;
    JLabel cube;
    JLabel factorial;

    public CalculatorPanel(){
        operations = new Operation[8];
        JFrame frame = new JFrame("Calculator");
        JPanel panel = new JPanel();
        JPanel panel2 = new JPanel();
        number1 = new JTextField("Number1");
        number2 = new JTextField("Number2");
        result = new JLabel("Result: ");
        addition = new JLabel("Addition: ");
        subtraction = new JLabel("Subtraction: ");
        division = new JLabel("Division: ");
        multiplication = new JLabel("Multiplication");
        root = new JLabel("Root:");
        square = new JLabel("Square:");
        cube = new JLabel("Cube:");
        factorial = new JLabel("Factorial");

        addOperations();
        additionButton = new CalculatorButton(operations[0], number1,number2,result,"Addition", addition,this);
        subtractionButton = new CalculatorButton(operations[1], number1,number2,result,"Subtraction", subtraction,this);
        divisionButton = new CalculatorButton(operations[2], number1,number2,result,"Division" , division,this);
        multiplicationButton = new CalculatorButton(operations[3], number1,number2,result,"Multiplication" , multiplication,this);
        rootButton = new UnaryCalculationButton(operations[4], number1, number2, result, "Root", root,this);
        squareButton = new UnaryCalculationButton(operations[5], number1, number2, result, "Square", square,this);
        cubeButton = new UnaryCalculationButton(operations[6], number1, number2, result,"Cube", cube,this);
        factorialButton = new UnaryCalculationButton(operations[7], number1,number2, result, "Factorial" , factorial,this);
        rootButton.setBackground(Color.red);
        squareButton.setBackground(Color.red);
        cubeButton.setBackground(Color.red);
        factorialButton.setBackground(Color.red);

        this.setBounds(0,0,100,100);
        this.add(number1);
        this.add(number2);
        this.add(result);
        this.setBounds(0,0,100,100);

        panel.add(additionButton);
        panel.add(subtractionButton);
        panel.add(divisionButton);
        panel.add(multiplicationButton);
        panel.add(rootButton);
        panel.add(squareButton);
        panel.add(cubeButton);
        panel.add(factorialButton);
        panel.setBounds(200,200,100,100);
        panel.add(addition);
        panel.add(subtraction);
        panel.add(division);
        panel.add(multiplication);
        panel.add(root);
        panel.add(square);
        panel.add(cube);
        panel.add(factorial);

        panel2.add(panel);
        panel2.add(this);
        panel2.setLayout(new GridLayout());
        frame.add(panel2);
        frame.setSize(1000,300);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout());
        frame.setVisible(true);
    }

    public void addOperations(){
        operations[0] = new Addition();
        operations[1] = new Subtraction();
        operations[2] = new Division();
        operations[3] = new Multiplication();
        operations[4] = new Root();
        operations[5] = new Square();
        operations[6] = new Cube();
        operations[7] = new Factorial();
    }

    public void calculateAndUpdateCountMessage(Operation operation){
        operation.addDone();
    }

    @Override
    public void countUpdated(Operation operation) {
        calculateAndUpdateCountMessage(operation);
    }
}
