import javax.swing.*;
import java.awt.event.ActionEvent;

public class UnaryCalculationButton extends CalculatorButton{

    public UnaryCalculationButton(Operation operation, JTextField number1, JTextField number2, JLabel result, String operationName, JLabel operationDone,CountInformer countInformer){
        super(operation, number1,number2, result, operationName, operationDone, countInformer);
        this.countInformer = countInformer;
        this.operation = operation;
        this.number1 = number1;
        this.number2 = number2;
        this.operationName = operationName;
        this.setText(operationName);
        this.addActionListener(this);
        this.result = result;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(!(operation.isBinaryOrUnary())){
            String a = number1.getText();
            if(a.equalsIgnoreCase("Number1")){
                result.setText("Result can not be calculated.");
            }
            else {
                int number = Integer.parseInt(a);
                result.setText("Result: " + operation.calculateResult(number, 0));
                countInformer.countUpdated(operation);
                operationDone.setText(operationName + ": " + (operation.getDone() / 2));
                number2.setText("Number2");
            }
        }
    }
}
