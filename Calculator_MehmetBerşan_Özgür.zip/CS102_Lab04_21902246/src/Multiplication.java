public class Multiplication extends Operation{

    @Override
    public double calculateResult(int a, int b) {
        setBinaryOrUnary(true);
        return a * b;
    }
}
