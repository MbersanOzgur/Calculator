public class Factorial extends Operation{

    @Override
    public double calculateResult(int a, int b) {
        setBinaryOrUnary(false);
        int factorial = 1;
        for(int i = 1; i <= a; i++){
            factorial = factorial * i;
        }
        return factorial;
    }
}
