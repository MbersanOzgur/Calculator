public abstract class Operation {

    private int Done;
    private boolean binaryOrUnary;
    private String operationName;

    public Operation(){
        Done = 0;
    }
    public abstract double calculateResult(int a, int b);

    public void addDone(){
        Done ++;
    }

    public int getDone(){
        return Done;
    }

    public boolean isBinaryOrUnary() {
        return binaryOrUnary;
    }

    public void setBinaryOrUnary(boolean binaryOrUnary) {
        this.binaryOrUnary = binaryOrUnary;
    }
}
